#ifndef MENU_H_INCLUDED
#define MENU_H_INCLUDED


void menu();
void tutorial();


#endif // MENU_H_INCLUDED
