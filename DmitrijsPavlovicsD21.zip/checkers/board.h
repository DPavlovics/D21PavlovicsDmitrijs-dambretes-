#ifndef BOARD_H_INCLUDED
#define BOARD_H_INCLUDED
using namespace std;

void grafika();
void change(bool,int,int);

class kaulini{

    public:
        string vards;
        char puse;
        char damka;

};

#endif // BOARD_H_INCLUDED
